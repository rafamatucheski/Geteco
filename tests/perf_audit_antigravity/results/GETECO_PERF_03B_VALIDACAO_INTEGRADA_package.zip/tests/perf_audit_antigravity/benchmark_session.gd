extends SceneTree

const HARBOR_SCENE := "res://world/harbor/HarborGame.tscn"

var failures: Array[String] = []
var log_lines: Array[String] = []
var report_data: Dictionary = {}

var session_id: String = "session"
var target_drive_duration_s: float = 60.0
var is_extended: bool = false
var out_dir: String = "tests/perf_audit_antigravity/results/benchmark"

func log_msg(msg: String) -> void:
	print(msg)
	log_lines.append(msg)

func _initialize() -> void:
	_load_config()
	_run.call_deferred()

func _load_config() -> void:
	var cfg_path := "tests/perf_audit_antigravity/session_config.json"
	if FileAccess.file_exists(cfg_path):
		var file := FileAccess.open(cfg_path, FileAccess.READ)
		if file:
			var text := file.get_as_text()
			file.close()
			var json = JSON.parse_string(text)
			if json is Dictionary:
				session_id = String(json.get("session_id", session_id))
				target_drive_duration_s = float(json.get("active_drive_seconds", target_drive_duration_s))
				is_extended = bool(json.get("extended", is_extended))
				out_dir = String(json.get("out_dir", out_dir))
	log_msg("Configuracao: session_id=%s, drive_s=%.1f, extended=%s, out_dir=%s" % [session_id, target_drive_duration_s, str(is_extended), out_dir])

func _run() -> void:
	# Generous watchdog: 360 seconds (6 minutes)
	create_timer(360.0).timeout.connect(func():
		log_msg("[WATCHDOG] Benchmark session %s timed out after 360s" % session_id)
		quit(2)
	)

	report_data["session_id"] = session_id
	report_data["target_drive_duration_s"] = target_drive_duration_s
	report_data["is_extended"] = is_extended
	report_data["timestamp"] = Time.get_datetime_string_from_system()

	# Skip onboarding
	var campaign: Node = root.get_node("CampaignState")
	for flag in [&"harbor_arrival_seen", &"harbor_arrival_call_complete", &"harbor_maciota_met", &"harbor_delivery_started", &"harbor_delivery_picked_up", &"harbor_delivery_complete"]:
		campaign.set_campaign_flag(flag, true)

	var mem_start_mb := float(OS.get_static_memory_usage()) / 1048576.0
	report_data["memory_start_mb"] = mem_start_mb

	change_scene_to_file(HARBOR_SCENE)
	
	var harbor: Node2D = null
	var stream: Node = null
	var boot_deadline := Time.get_ticks_msec() + 30000
	while Time.get_ticks_msec() < boot_deadline:
		await process_frame
		harbor = current_scene as Node2D
		if harbor != null and harbor.name == "HarborGame":
			stream = harbor.get_node_or_null("ContinuousWorld")
			if stream != null:
				break

	if harbor == null or stream == null:
		failures.append("HarborGame or ContinuousWorld failed to initialize")
		_finish(1)
		return

	# Disable traffic collisions
	for vehicle in get_nodes_in_group("modern_traffic"):
		vehicle.collision_layer = 0
		vehicle.set_physics_process(false)

	var player: Node2D = harbor.get_node_or_null("Player")
	var car_manager := harbor.get_node_or_null("PersonalCarManager")
	var car: Node2D = car_manager.car if (car_manager != null and car_manager.get("car") != null) else null
	if car == null:
		car = preload("res://world/mountain_pass/MountainSUV.gd").new()
		car.position = Vector2(6120, -4100)
		harbor.add_child(car)
	else:
		car.global_position = Vector2(6120, -4100)

	car.call("enter_vehicle", player)
	var boarding_deadline := Time.get_ticks_msec() + 5000
	while car.has_meta("vehicle_boarding") and Time.get_ticks_msec() < boarding_deadline:
		await physics_frame

	log_msg("[1/6] Carro preparado e jogador embarcado.")

	# Drive towards bridge approach (y < -1000 triggers ensure_mountain)
	var connector = preload("res://world/harbor/HarborMountainConnector.gd")
	var outbound_points: PackedVector2Array = connector.road_definitions()[0].points

	var t0_stream := Time.get_ticks_msec()
	var stream_frames := 0
	var stream_frame_times: Array[float] = []
	var prev_tick := Time.get_ticks_usec()

	# Start background streaming measurement while driving to bridge approach
	var approaching := true
	var app_target: Vector2 = outbound_points[0]

	while not bool(stream.get("ready_for_crossing")):
		var now := Time.get_ticks_usec()
		var dt_ms := float(now - prev_tick) / 1000.0
		prev_tick = now
		if stream_frames > 0: # skip first frame setup delta
			stream_frame_times.append(dt_ms)
		stream_frames += 1

		# Drive towards bridge entrance
		if approaching and car.global_position.distance_to(app_target) > 10.0:
			var dir := car.global_position.direction_to(app_target)
			car.rotation = dir.angle()
			car.set("velocity", dir * 120.0)
			car.move_and_collide(dir * minf(16.0, car.global_position.distance_to(app_target)))
		else:
			approaching = false

		await process_frame

	var stream_duration_ms := Time.get_ticks_msec() - t0_stream
	var mountain_node: Node2D = stream.get("mountain")
	var mem_stream_mb := float(OS.get_static_memory_usage()) / 1048576.0

	var stream_spikes_gt_16 := 0
	var stream_spikes_gt_33 := 0
	var stream_spikes_gt_50 := 0
	var stream_spikes_gt_100 := 0
	var stream_max_frame := 0.0
	for ft in stream_frame_times:
		if ft > 16.67: stream_spikes_gt_16 += 1
		if ft > 33.33: stream_spikes_gt_33 += 1
		if ft > 50.0: stream_spikes_gt_50 += 1
		if ft > 100.0: stream_spikes_gt_100 += 1
		if ft > stream_max_frame: stream_max_frame = ft

	report_data["stream_duration_ms"] = stream_duration_ms
	report_data["stream_frames_count"] = stream_frames
	report_data["stream_max_frame_ms"] = stream_max_frame
	report_data["stream_spikes_gt_16ms"] = stream_spikes_gt_16
	report_data["stream_spikes_gt_33ms"] = stream_spikes_gt_33
	report_data["stream_spikes_gt_50ms"] = stream_spikes_gt_50
	report_data["stream_spikes_gt_100ms"] = stream_spikes_gt_100
	report_data["memory_post_stream_mb"] = mem_stream_mb

	log_msg("[2/6] Streaming MountainPass: %d ms em %d frames. Spikes >16ms: %d, >33ms: %d, >50ms: %d, >100ms: %d, max: %.2f ms" % [
		stream_duration_ms, stream_frames, stream_spikes_gt_16, stream_spikes_gt_33, stream_spikes_gt_50, stream_spikes_gt_100, stream_max_frame
	])

	# Cross bridge to Mountain Pass
	for i in range(1, outbound_points.size()):
		await _drive_step(car, outbound_points[i], 140.0)

	var entry_target := Vector2(7450, -4540)
	await _drive_step(car, entry_target, 140.0)

	# Measure presentation frame
	var t_pres_start := Time.get_ticks_usec()
	await process_frame
	stream.call("_update_region")
	await physics_frame
	var presentation_frame_ms := float(Time.get_ticks_usec() - t_pres_start) / 1000.0
	report_data["first_presentation_frame_ms"] = presentation_frame_ms

	var current_reg := String(stream.get("current_region"))
	if current_reg != "mountain":
		failures.append("Failed to switch to mountain region on crossing (is %s)" % current_reg)
	log_msg("[3/6] Travessia da fronteira concluida. Quadro de apresentacao: %.2f ms, regiao: %s" % [presentation_frame_ms, current_reg])

	var initial_mountain_nodes := mountain_node.get_child_count()
	report_data["initial_mountain_nodes"] = initial_mountain_nodes

	# Active driving in Mountain Pass for >= target_drive_duration_s
	log_msg("[4/6] Iniciando conducao ativa na montanha (meta: >= %.1f s)..." % target_drive_duration_s)
	var active_frame_times: Array[float] = []
	var t_drive_start := Time.get_ticks_msec()
	var drive_deadline := t_drive_start + int(target_drive_duration_s * 1000.0)

	var circuit_waypoints: PackedVector2Array = [
		Vector2(7550, -4550),
		Vector2(7750, -4580),
		Vector2(7950, -4620),
		Vector2(8150, -4600),
		Vector2(7950, -4620),
		Vector2(7750, -4580),
		Vector2(7500, -4550)
	]

	var wp_idx := 0
	var last_frame_time := Time.get_ticks_usec()

	while Time.get_ticks_msec() < drive_deadline:
		var target := circuit_waypoints[wp_idx]
		var dir := car.global_position.direction_to(target)
		car.rotation = dir.angle()
		car.set("velocity", dir * 140.0)
		car.move_and_collide(dir * minf(16.0, car.global_position.distance_to(target)))

		if car.global_position.distance_to(target) <= 24.0:
			wp_idx = (wp_idx + 1) % circuit_waypoints.size()

		await process_frame
		var cur_time := Time.get_ticks_usec()
		var dt_ms := float(cur_time - last_frame_time) / 1000.0
		last_frame_time = cur_time
		active_frame_times.append(dt_ms)

	var actual_drive_duration_s := float(Time.get_ticks_msec() - t_drive_start) / 1000.0
	report_data["actual_drive_duration_s"] = actual_drive_duration_s

	# Calculate active drive metrics
	var active_metrics := _calculate_frame_metrics(active_frame_times, actual_drive_duration_s)
	report_data["active_drive_metrics"] = active_metrics
	log_msg("  Conducao ativa: %.1fs, %d frames, FPS medio: %.1f, p50: %.2f ms, p95: %.2f ms, p99: %.2f ms, pior: %.2f ms" % [
		actual_drive_duration_s, active_frame_times.size(), active_metrics["fps_avg"],
		active_metrics["p50_ms"], active_metrics["p95_ms"], active_metrics["p99_ms"], active_metrics["worst_ms"]
	])
	log_msg("  Spikes ativos: >16ms=%d, >33ms=%d, >50ms=%d, >100ms=%d" % [
		active_metrics["spikes_gt_16ms"], active_metrics["spikes_gt_33ms"], active_metrics["spikes_gt_50ms"], active_metrics["spikes_gt_100ms"]
	])

	# Drive back to Harbor
	log_msg("[5/6] Retornando pela ponte inbound ao Harbor...")
	var inbound_points: PackedVector2Array = connector.road_definitions()[1].points
	for i in range(1, inbound_points.size()):
		await _drive_step(car, inbound_points[i], 140.0)

	var harbor_return_target := Vector2(5800, -4100)
	await _drive_step(car, harbor_return_target, 140.0)

	for i in 20: await process_frame
	stream.call("_update_region")
	for i in 5: await physics_frame

	current_reg = String(stream.get("current_region"))
	if current_reg != "harbor":
		failures.append("Return to harbor did not switch region (is %s)" % current_reg)
	log_msg("  Retorno concluido: posicao=%s, current_region=%s" % [str(car.global_position), current_reg])

	# Re-entry into Mountain Pass
	log_msg("[6/6] Testando REENTRADA na Mountain Pass...")
	for i in range(0, outbound_points.size()):
		await _drive_step(car, outbound_points[i], 140.0)
	await _drive_step(car, entry_target, 140.0)

	for i in 20: await process_frame
	var t_reentry_start := Time.get_ticks_usec()
	await process_frame
	stream.call("_update_region")
	await physics_frame
	var reentry_spike_ms := float(Time.get_ticks_usec() - t_reentry_start) / 1000.0
	report_data["reentry_spike_ms"] = reentry_spike_ms

	current_reg = String(stream.get("current_region"))
	if current_reg != "mountain":
		failures.append("Re-entry did not switch region (is %s)" % current_reg)
	log_msg("  Reentrada concluida: quadro de reentrada: %.2f ms, regiao=%s" % [reentry_spike_ms, current_reg])

	# If extended session (B3), perform an extra loop and return-reentry cycle
	if is_extended:
		log_msg("  [SESSAO ESTENDIDA] Executando ciclo adicional de conducao e segunda reentrada...")
		for i in range(circuit_waypoints.size()):
			await _drive_step(car, circuit_waypoints[i], 140.0)
		for i in range(1, inbound_points.size()):
			await _drive_step(car, inbound_points[i], 140.0)
		await _drive_step(car, harbor_return_target, 140.0)
		for i in 20: await process_frame
		stream.call("_update_region")
		for i in 5: await physics_frame
		log_msg("    Segunda volta Harbor: regiao=%s" % str(stream.get("current_region")))

		for i in range(0, outbound_points.size()):
			await _drive_step(car, outbound_points[i], 140.0)
		await _drive_step(car, entry_target, 140.0)
		for i in 20: await process_frame
		stream.call("_update_region")
		for i in 5: await physics_frame
		log_msg("    Segunda reentrada Mountain: regiao=%s" % str(stream.get("current_region")))

	# Node count stability check
	var final_mountain_nodes := mountain_node.get_child_count()
	report_data["final_mountain_nodes"] = final_mountain_nodes
	log_msg("  Contagem de nos MountainPass: inicial=%d, final=%d" % [initial_mountain_nodes, final_mountain_nodes])
	if final_mountain_nodes != initial_mountain_nodes:
		failures.append("Node leak: mountain child count changed from %d to %d" % [initial_mountain_nodes, final_mountain_nodes])

	var mem_end_mb := float(OS.get_static_memory_usage()) / 1048576.0
	report_data["memory_end_mb"] = mem_end_mb

	# Vehicle exit
	car.call("force_exit_vehicle")
	player.set("is_control_disabled", false)
	for i in 10: await physics_frame

	report_data["failures"] = failures
	_finish(0 if failures.is_empty() else 1, active_frame_times)

func _drive_step(car: Node2D, target: Vector2, speed: float) -> void:
	var max_frames := 180
	var frames := 0
	while car.global_position.distance_to(target) > 8.0 and frames < max_frames:
		var dir := car.global_position.direction_to(target)
		car.rotation = dir.angle()
		car.set("velocity", dir * speed)
		var dist := minf(16.0, car.global_position.distance_to(target))
		var collision: KinematicCollision2D = car.move_and_collide(dir * dist)
		if collision:
			car.global_position += dir.orthogonal() * 2.0
		await physics_frame
		frames += 1

func _calculate_frame_metrics(frame_times: Array[float], duration_s: float) -> Dictionary:
	if frame_times.is_empty():
		return {}
	var sorted := frame_times.duplicate()
	sorted.sort()
	var total := 0.0
	var s_16 := 0
	var s_33 := 0
	var s_50 := 0
	var s_100 := 0
	for ft in frame_times:
		total += ft
		if ft > 16.67: s_16 += 1
		if ft > 33.33: s_33 += 1
		if ft > 50.0: s_50 += 1
		if ft > 100.0: s_100 += 1

	var count := frame_times.size()
	return {
		"frames_count": count,
		"duration_s": duration_s,
		"fps_avg": float(count) / duration_s if duration_s > 0 else 0.0,
		"avg_ms": total / float(count),
		"p50_ms": _percentile(sorted, 0.50),
		"p90_ms": _percentile(sorted, 0.90),
		"p95_ms": _percentile(sorted, 0.95),
		"p99_ms": _percentile(sorted, 0.99),
		"worst_ms": sorted[-1],
		"best_ms": sorted[0],
		"spikes_gt_16ms": s_16,
		"spikes_gt_33ms": s_33,
		"spikes_gt_50ms": s_50,
		"spikes_gt_100ms": s_100
	}

func _percentile(sorted_values: Array, fraction: float) -> float:
	var idx: int = clampi(int(sorted_values.size() * fraction), 0, sorted_values.size() - 1)
	return sorted_values[idx]

func _finish(exit_code: int, raw_frame_times: Array[float] = []) -> void:
	report_data["exit_code"] = exit_code
	DirAccess.make_dir_recursive_absolute(out_dir)

	var f := FileAccess.open(out_dir + "/report.json", FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(report_data, "  "))
		f.close()

	var flog := FileAccess.open(out_dir + "/session.log", FileAccess.WRITE)
	if flog:
		flog.store_string("\n".join(log_lines))
		flog.close()

	if not raw_frame_times.is_empty():
		var fcsv := FileAccess.open(out_dir + "/frame_times.csv", FileAccess.WRITE)
		if fcsv:
			fcsv.store_line("frame_index,frame_time_ms")
			for i in range(raw_frame_times.size()):
				fcsv.store_line("%d,%.3f" % [i, raw_frame_times[i]])
			fcsv.close()

	log_msg("=== SESSAO %s: %s (exit_code=%d) ===" % [session_id, "APROVADA" if exit_code == 0 else "FALHOU", exit_code])
	quit(exit_code)
